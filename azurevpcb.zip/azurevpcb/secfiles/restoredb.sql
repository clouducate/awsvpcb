CREATE LOGIN AppAcc_CTS4743_MyFIU WITH PASSWORD = 'K!0*M$ZjwYU+HKd3k-LNlE[FVbkf_(o7' DEFAULT_DATABASE = ContosoUniversity
go

RESTORE DATABASE ContosoUniversity
    FROM DISK = 'secfiles/ContosoUniversity.bak'
    WITH FILE = 1,
      RECOVERY;
go