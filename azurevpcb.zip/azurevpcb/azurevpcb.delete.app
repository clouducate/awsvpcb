export logfile=logs/azurevpcb.delete.app.log
export userid=$(az account show --query user.name | cut -f2 -d"\"" | cut -f1 -d"@")
export defaultSubscription="Azure for Students"
echo $(date) "Running azurevpcb.delete.app" >> $logfile

if [ "$1" != "" ] ; then
   t=`[ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null`
   if [ $? -ne 0 ]; then
      echo $(date) "Restart Step must be a number - cancelling operations...."
      exit 1
   fi
   export restartStep=$1
else
   export restartStep=0
fi

#echo "Deleting NAT Gateway..."
#echo $(date) "Deleting NAT Gateway..." >> $logfile
#./procs/azurevpcb.delete.app.nat 
#if [ $? -ne 0 ]; then
#   exit 1
#fi

echo $(date) "Deleting Bastion Server..."
echo $(date) "Deleting Bastion Server..." >> $logfile
az vm delete --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --yes >> $logfile 2>> $logfile
if [ $? -ne 0 ]; then
   echo $(date) "Error detected! Run ./azurevpcb.diaglog"
   echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
   exit 1
fi
echo $(date) "Bastion server successfully deleted..."
echo $(date) "Bastion server successfully deleted..." >> $logfile

echo $(date) "Deleting Public IPs..."
echo $(date) "Deleting Public IPs..." >> $logfile
az network public-ip delete --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
if [ $? -ne 0 ]; then
   echo $(date) "Error detected! Run ./azurevpcb.diaglog"
   echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
   exit 1
fi

echo $(date) "Deleting Database..."
echo $(date) "Deleting Database..." >> $logfile
./procs/azurevpcb.delete.app.db 
if [ $? -ne 0 ]; then
   exit 1
fi

echo $(date) "Deleting App Service..."
echo $(date) "Deleting App Service..." >> $logfile
./procs/azurevpcb.delete.app.web 
if [ $? -ne 0 ]; then
   exit 1
fi

exit

