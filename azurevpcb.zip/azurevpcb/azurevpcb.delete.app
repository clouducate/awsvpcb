export logfile=logs/azurevpcb.delete.app.log
export userid=$(az account show --query user.name | cut -f2 -d"\"" | cut -f1 -d"@")
export defaultSubscription="Azure for Students"
echo $(date) "Running azurevpcb.delete.app" >> $logfile

if [ "$1" != "" ] ; then
   t=`[ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null`
   if [ $? -ne 0 ]; then
      echo $(date) "Restart Step must be a number - cancelling operations...."
      exit 1
   fi
   export restartStep=$1
else
   export restartStep=0
fi

# Keep going when one delete fails: after a partial create (say the Bastion VM was never
# built) the remaining resources still have to go.  Deleting something that does not
# exist succeeds, so a failure here is a real error - report it at the end.
FAILED=0
run_delete_step() {
   step_desc="$1"
   shift
   "$@" >> $logfile 2>> $logfile
   if [ $? -ne 0 ]; then
      echo $(date) "$step_desc failed.  Continuing with the rest of the cleanup..." | tee -a $logfile
      FAILED=1
   fi
}

#echo "Deleting NAT Gateway..."
#echo $(date) "Deleting NAT Gateway..." >> $logfile
#./procs/azurevpcb.delete.app.nat 
#if [ $? -ne 0 ]; then
#   exit 1
#fi

echo $(date) "Deleting Bastion Server..."
echo $(date) "Deleting Bastion Server..." >> $logfile
run_delete_step "Deleting the Bastion server" \
   az vm delete --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --yes
# Normally removed with the VM (--nic-delete-option Delete), but not after a failed create.
run_delete_step "Deleting the Bastion server network interface" \
   az network nic delete --name vm-vpcb-bastionVMNic --subscription "$defaultSubscription" --resource-group AzureVPCB

echo $(date) "Deleting Public IPs..."
echo $(date) "Deleting Public IPs..." >> $logfile
run_delete_step "Deleting the Bastion public IP" \
   az network public-ip delete --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB

echo $(date) "Deleting Database..."
echo $(date) "Deleting Database..." >> $logfile
./procs/azurevpcb.delete.app.db 
if [ $? -ne 0 ]; then
   FAILED=1
fi

echo $(date) "Deleting App Service..."
echo $(date) "Deleting App Service..." >> $logfile
./procs/azurevpcb.delete.app.web 
if [ $? -ne 0 ]; then
   FAILED=1
fi

if [ $FAILED -ne 0 ]; then
   echo $(date) "Error detected! Run ./azurevpcb.diaglog"
   echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
   exit 1
fi
echo $(date) "Successful completion of azurevpcb.delete.app"
echo $(date) "Successful completion of azurevpcb.delete.app" >> $logfile
exit
