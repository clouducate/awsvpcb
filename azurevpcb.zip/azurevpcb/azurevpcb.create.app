export logfile=logs/azurevpcb.create.app.log
export userid=$(az account show --query user.name | cut -f2 -d"\"" | cut -f1 -d"@")
export vpcbAppRegion=$(cat tempfiles/Appregion)
#export vpcbDBRegion=$(cat tempfiles/DBregion)
export vpcbBastionRegion=$(cat tempfiles/Bastionregion)
export Region_List="eastus2 westus2 centralus northcentralus westus westus3 eastus eastus3 westcentralus southcentralus"
export defaultSubscription="Azure for Students"
echo $(date) "Running azurevpcb.create.app" >> $logfile

if [ "$1" != "" ] ; then
   t=`[ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null`
   if [ $? -ne 0 ]; then
      echo "Restart Step must be a number - cancelling operations...."
      exit 1
   fi
   export restartStep=$1
else
   export restartStep=0
fi

if [ $restartStep -le 5 ]; then
   echo "Creating Bastion Server..."
   echo $(date) "Creating Bastion Server..." >> $logfile
   SUCCESS=0
   for vpcbRegion in $Region_List; do
      az network vnet subnet delete --name subnet-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB \
        --vnet-name vnet-VPCBBastion >> $logfile 2>> $logfile
      az network public-ip delete --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      az network vnet delete --name vnet-VPCBBastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      az network nsg delete --name nsg-VPCB-PUBLIC  --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      echo "Creating Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..."
      echo $(date) "Attempting to create Public IP for Bastion Server in region $vpcbRegion..." >> $logfile
      az network public-ip create --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
         --allocation-method Static --version IPv4 --zone 1 --location $vpcbRegion >> $logfile 2>> $logfile
      if [ $? -ne 0 ]; then 
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      echo "Creating NSG for App Service in $vpcbRegion region..." >> $logfile
      az network nsg create --name nsg-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB \
         --location $vpcbRegion >> $logfile 2>> $logfile
      if [ $? -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      echo $(date) "Attempting to create vnet-VPCBBastion in region $vpcbRegion..." >> $logfile
      az network vnet create --name vnet-VPCBBastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
         --address-prefixes 172.30.0.0/16 --location $vpcbRegion >> $logfile 2>> $logfile
      if [ $? -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      az network vnet subnet create --name subnet-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB  \
         --vnet-name vnet-VPCBBastion --address-prefixes 172.30.132.0/24 --network-security-group nsg-VPCB-PUBLIC >> $logfile 2>> $logfile
      if [ $? -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      echo $(date) "Attempting to create Bastion Server in region $vpcbRegion..." >> $logfile
      az vm create --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --admin-password sI11ybUt6ood \
                --admin-username vpcb-admin \
                --image Win2022Datacenter --accept-term --nsg nsg-VPCB-PUBLIC --location $vpcbRegion \
                --private-ip-address 172.30.132.45 --public-ip-address ip-vpcb-bastion \
                --size Standard_B2ls_v2 --subnet subnet-VPCB-PUBLIC --vnet-name vnet-VPCBBastion --os-disk-delete-option Delete \
                --nic-delete-option Delete >> $logfile 2>> $logfile
      if [ $? -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      else
         SUCCESS=1
         break
      fi
   done
   if [ $SUCCESS -eq 0 ]; then
      echo "Error detected! Run ./azurevpcb.diaglog"
      echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
      exit 1
   fi
   echo "Bastion server successfully created in region $vpcbRegion..."
   echo $(date) "Bastion server successfully created..." >> $logfile
fi

vpcbBastionRegion=$vpcbRegion
echo $vpcbBastionRegion > tempfiles/Bastionregion


if [ $restartStep -lt 20 ]; then
   ./procs/azurevpcb.create.app.db 
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi   

if [ $restartStep -lt 30 ]; then
   ./procs/azurevpcb.create.app.web 
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

exit

./procs/azurevpcb.create.app.dns 
if [ $? -ne 0 ]; then
   exit 1
fi