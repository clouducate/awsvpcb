export logfile=logs/azurevpcb.create.app.log
export userid=$(az account show --query user.name | cut -f2 -d"\"" | cut -f1 -d"@")
export vpcbAppRegion=$(cat tempfiles/Appregion 2>/dev/null)
#export vpcbDBRegion=$(cat tempfiles/DBregion)
export vpcbBastionRegion=$(cat tempfiles/Bastionregion 2>/dev/null)
# Region list and the policy-aware region retry helpers live in procs/azurevpcb.regions
. ./procs/azurevpcb.regions
export Region_List="$(load_region_list)"

export defaultSubscription="Azure for Students"
# Windows Server image for the Bastion server.  procs/azurevpcb.probe validates with this
# same image, so what it approves is what gets built.  (2022-datacenter-g2 is scheduled
# for deprecation on 2027-01-15.)
export Bastion_Image_Sku="2025-datacenter-g2"
echo $(date) "Running azurevpcb.create.app" >> $logfile

if [ "$1" != "" ] ; then
   t=`[ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null`
   if [ $? -ne 0 ]; then
      echo $(date) "Restart Step must be a number - cancelling operations...."
      exit 1
   fi
   export restartStep=$1
else
   export restartStep=0
fi

if [ $restartStep -le 5 ]; then
   echo $(date) "Creating Bastion Server..."
   echo $(date) "Creating Bastion Server..." >> $logfile
   # A rerun (or a restart below step 5) should not rebuild a Bastion server that is
   # already there and working - that is the slowest part of this script.
   read vmLocation vmState vmSize <<< $(az vm show --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
      --query "[location, provisioningState, hardwareProfile.vmSize]" -o tsv 2>/dev/null | tr -d '\r' | tr '\n' ' ')
   if [ "$vmState" = "Succeeded" ]; then
      echo $(date) "Bastion server already exists in region $vmLocation (VM size $vmSize).  Keeping it..." | tee -a $logfile
      vpcbRegion=$vmLocation
   else
      # Ask Azure which (region, VM size) pairs this subscription can actually use - every
      # student's allowed regions, quotas and capacity differ.  See procs/azurevpcb.probe.
      echo $(date) "Checking which regions and VM sizes your subscription can use (this takes a few minutes)..."
      ./procs/azurevpcb.probe
      if [ $? -ne 0 ]; then
         echo $(date) "Error detected! Run ./azurevpcb.diaglog"
         echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
         exit 1
      fi
      SUCCESS=0
      REGIONS_NARROWED=0
      netRegion=""
      # Validation is only a snapshot, so a real create can still fail: fall back to the
      # next candidate.  The network is only rebuilt when the region changes.  fd 3 keeps
      # az from reading the candidate list on stdin.
      exec 3< tempfiles/BastionCandidates
      while read -u 3 vpcbRegion vmSize; do
         if ! echo " $(load_region_list) " | grep -q " $vpcbRegion "; then
            continue
         fi
         if [ "$vpcbRegion" != "$netRegion" ]; then
            netRegion=""
            az vm delete --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --yes >> $logfile 2>> $logfile
            az network nic delete --name vm-vpcb-bastionVMNic --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
            az network vnet subnet delete --name subnet-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB \
              --vnet-name vnet-VPCBBastion >> $logfile 2>> $logfile
            az network vnet delete --name vnet-VPCBBastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
            az network nsg delete --name nsg-VPCB-PUBLIC  --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
            az network public-ip delete --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
            echo $(date) "Creating Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
            # No --zone: the VM is regional, and the probe validated a regional IP.
            run_region_step "Public IP create" \
               az network public-ip create --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
               --allocation-method Static --version IPv4 --location $vpcbRegion &&
            run_region_step "NSG create" \
               az network nsg create --name nsg-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB \
               --location $vpcbRegion &&
            run_region_step "VNET create" \
               az network vnet create --name vnet-VPCBBastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
               --address-prefixes 172.30.0.0/16 --location $vpcbRegion &&
            run_region_step "Subnet create" \
               az network vnet subnet create --name subnet-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB  \
               --vnet-name vnet-VPCBBastion --address-prefixes 172.30.132.0/24 --network-security-group nsg-VPCB-PUBLIC
            if [ $? -ne 0 ]; then
               echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
               continue
            fi
            netRegion=$vpcbRegion
         else
            # Clear out what a failed attempt in this region left behind.
            az vm delete --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --yes >> $logfile 2>> $logfile
            az network nic delete --name vm-vpcb-bastionVMNic --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
         fi
         echo $(date) "Trying to create Bastion Server with VM size $vmSize in region $vpcbRegion..." | tee -a $logfile
         # Same image as procs/azurevpcb.bastion.probe.json, so the probe tested what we build.
         run_region_step "VM create" \
            az vm create --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --admin-password sI11ybUt6ood \
                --admin-username vpcb-admin \
                --image MicrosoftWindowsServer:WindowsServer:$Bastion_Image_Sku:latest --accept-term --nsg nsg-VPCB-PUBLIC --location $vpcbRegion \
                --private-ip-address 172.30.132.45 --public-ip-address ip-vpcb-bastion \
                --size $vmSize --subnet subnet-VPCB-PUBLIC --vnet-name vnet-VPCBBastion --os-disk-delete-option Delete \
                --nic-delete-option Delete
         if [ $? -eq 0 ]; then
            SUCCESS=1
            break
         fi
         echo $(date) "VM size $vmSize failed in region $vpcbRegion.  Trying the next candidate..." | tee -a $logfile
      done
      exec 3<&-
      if [ $SUCCESS -eq 0 ]; then
         clear_region_list
         echo $(date) "None of the VM sizes that passed Azure's checks could actually be created.  Azure capacity changes constantly - please try again later." | tee -a $logfile
         echo $(date) "Error detected! Run ./azurevpcb.diaglog"
         echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
         exit 1
      fi
   fi
   vpcbBastionRegion=$vpcbRegion
   echo $vpcbBastionRegion > tempfiles/Bastionregion
   export Region_List="$(load_region_list)"
   echo $(date) "Bastion server ready in region $vpcbRegion with VM size $vmSize..."
   echo $(date) "Bastion server ready in region $vpcbRegion with VM size $vmSize..." >> $logfile
fi


if [ $restartStep -lt 20 ]; then
   ./procs/azurevpcb.create.app.db 
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi   

if [ $restartStep -lt 30 ]; then
   ./procs/azurevpcb.create.app.web 
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

exit
