export logfile=logs/azurevpcb.create.app.log
export userid=$(az account show --query user.name | cut -f2 -d"\"" | cut -f1 -d"@")
export vpcbAppRegion=$(cat tempfiles/Appregion 2>/dev/null)
#export vpcbDBRegion=$(cat tempfiles/DBregion)
export vpcbBastionRegion=$(cat tempfiles/Bastionregion 2>/dev/null)
# Region list and the policy-aware region retry helpers live in procs/azurevpcb.regions
. ./procs/azurevpcb.regions
export Region_List="$(load_region_list)"

export VMFamily_List=( "Standard BS Family|Standard_B2s"
 "Standard Bsv2 Family|Standard_B2ls_v2"
 "Standard Dv3 Family|Standard_D2_v3"
 "Standard DSv3 Family|Standard_D2s_v3"
 "Standard Dv4 Family|Standard_D2_v4"
 "Standard DSv4 Family|Standard_D2s_v4"
 "Standard Basv2 Family|Standard_B2als_v2"
 "Standard Bpsv2 Family|Standard_B2pls_v2"
 "Standard Dv5 Family|Standard_D2_v5"
 "Standard DSv5 Family|Standard_D2s_v5"
 "Standard Dv6 Family|Standard_D2_v6"
 "Standard DSv6 Family|Standard_D2s_v6")

export defaultSubscription="Azure for Students"
echo $(date) "Running azurevpcb.create.app" >> $logfile

if [ "$1" != "" ] ; then
   t=`[ -n "$1" ] && [ "$1" -eq "$1" ] 2>/dev/null`
   if [ $? -ne 0 ]; then
      echo $(date) "Restart Step must be a number - cancelling operations...."
      exit 1
   fi
   export restartStep=$1
else
   export restartStep=0
fi

if [ $restartStep -le 5 ]; then
   echo $(date) "Creating Bastion Server..."
   echo $(date) "Creating Bastion Server..." >> $logfile
   SUCCESS=0
   REGIONS_NARROWED=0
   while true; do
    NARROWED_THIS_PASS=0
    for vpcbRegion in $Region_List; do
      az network nic delete --name vm-vpcb-bastionVMNic --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      az network vnet subnet delete --name subnet-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB \
        --vnet-name vnet-VPCBBastion >> $logfile 2>> $logfile
      az network vnet delete --name vnet-VPCBBastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      az network nsg delete --name nsg-VPCB-PUBLIC  --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      az network public-ip delete --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB >> $logfile 2>> $logfile
      echo $(date) "Creating Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..."
      echo $(date) "Attempting to create Public IP for Bastion Server in region $vpcbRegion..." >> $logfile
      run_region_step "Public IP create" \
         az network public-ip create --name ip-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
         --allocation-method Static --version IPv4 --zone 1 --location $vpcbRegion
      rc=$?
      if [ $rc -eq 2 ]; then NARROWED_THIS_PASS=1; break; fi
      if [ $rc -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      echo $(date) "Creating NSG for App Service in $vpcbRegion region..." >> $logfile
      run_region_step "NSG create" \
         az network nsg create --name nsg-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB \
         --location $vpcbRegion
      rc=$?
      if [ $rc -eq 2 ]; then NARROWED_THIS_PASS=1; break; fi
      if [ $rc -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      echo $(date) "Attempting to create vnet-VPCBBastion in region $vpcbRegion..." >> $logfile
      run_region_step "VNET create" \
         az network vnet create --name vnet-VPCBBastion --subscription "$defaultSubscription" --resource-group AzureVPCB \
         --address-prefixes 172.30.0.0/16 --location $vpcbRegion
      rc=$?
      if [ $rc -eq 2 ]; then NARROWED_THIS_PASS=1; break; fi
      if [ $rc -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      run_region_step "Subnet create" \
         az network vnet subnet create --name subnet-VPCB-PUBLIC --subscription "$defaultSubscription" --resource-group AzureVPCB  \
         --vnet-name vnet-VPCBBastion --address-prefixes 172.30.132.0/24 --network-security-group nsg-VPCB-PUBLIC
      rc=$?
      if [ $rc -eq 2 ]; then NARROWED_THIS_PASS=1; break; fi
      if [ $rc -ne 0 ]; then
         echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
         echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
         continue
      fi
      echo $(date) "Attempting to create Bastion Server in region $vpcbRegion..." >> $logfile
      for entry in "${VMFamily_List[@]}"; do
         family="${entry%|*}"
         vmSize="${entry#*|}"  
         quota=`az vm list-usage --location "$vpcbRegion" --output table | grep "$family"| tr -s ' ' | cut -d" " -f6`
         if [ $quota -gt 1 ]; then
            echo $(date) "Found that VM Family $family has a quota of $quota in region $vpcbRegion.  Trying to create VM..." | tee -a $logfile
            run_region_step "VM create" \
               az vm create --name vm-vpcb-bastion --subscription "$defaultSubscription" --resource-group AzureVPCB --admin-password sI11ybUt6ood \
                   --admin-username vpcb-admin \
                   --image Win2022Datacenter --accept-term --nsg nsg-VPCB-PUBLIC --location $vpcbRegion \
                   --private-ip-address 172.30.132.45 --public-ip-address ip-vpcb-bastion \
                   --size $vmSize --subnet subnet-VPCB-PUBLIC --vnet-name vnet-VPCBBastion --os-disk-delete-option Delete \
                   --nic-delete-option Delete
            rc=$?
            if [ $rc -eq 2 ]; then NARROWED_THIS_PASS=1; break; fi
            if [ $rc -ne 0 ]; then
               echo $(date) "Failed with region $vpcbRegion.  Trying another..." | tee -a $logfile
               echo $(date) "Deleting Public IP, NSG, VNET and Subnet for Bastion server in $vpcbRegion region..." | tee -a $logfile
               continue
            else
               SUCCESS=1
               break
            fi
         else
            echo $(date) "Found that VM Family $family has a quota of $quota in region $vpcbRegion.  Skipping..." | tee -a $logfile
         fi
      done
      if [ $SUCCESS -eq 1 ]; then
         break
      fi
      if [ $NARROWED_THIS_PASS -eq 1 ]; then
         break
      fi
    done
    if [ $SUCCESS -eq 1 ]; then
       break
    fi
    if [ $NARROWED_THIS_PASS -eq 1 ]; then
       continue
    fi
    break
   done
   if [ $SUCCESS -eq 0 ]; then
      clear_region_list
      echo $(date) "Error detected! Run ./azurevpcb.diaglog"
      echo $(date) "Error detected! Run ./azurevpcb.diaglog" >> $logfile
      exit 1
   fi
   vpcbBastionRegion=$vpcbRegion
   echo $vpcbBastionRegion > tempfiles/Bastionregion
   export Region_List="$(load_region_list)"
   echo $(date) "Bastion server successfully created in region $vpcbRegion..."
   echo $(date) "Bastion server successfully created..." >> $logfile
fi


if [ $restartStep -lt 20 ]; then
   ./procs/azurevpcb.create.app.db 
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi   

if [ $restartStep -lt 30 ]; then
   ./procs/azurevpcb.create.app.web 
   if [ $? -ne 0 ]; then
      exit 1
   fi
fi

exit
